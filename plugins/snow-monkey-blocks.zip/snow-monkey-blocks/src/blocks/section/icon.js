export default (
	<svg viewBox="0 0 24 24">
		<rect x="6" y="12.13" width="12" height="1" />
		<rect x="3" y="15.63" width="18" height="1" />
		<rect x="6" y="19.13" width="12" height="1" />
		<path d="M9.41,9.05h.16L12,7.14l2.43,1.91h.16a.15.15,0,0,0,.16-.15V4a.15.15,0,0,0-.16-.15H9.41A.15.15,0,0,0,9.25,4V8.9A.15.15,0,0,0,9.41,9.05Z" />
	</svg>
);
